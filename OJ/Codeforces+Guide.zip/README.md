# Info

> This directory contains all the source codes, results for the project I'm doing to provide a simple guide on how to solve codeforces problems.
